<!-- footer -->
<footer class="py-5 bg-dark" style=" position:absolute;bottom:0;width:100%;height: 50px;">
    <div class="container">
      <p class="m-0 text-center text-white">Bản quyền bởi &copy; <a href="https://nentang.vn">NenTang.vn</a>
        &copy; 2019-2020</p>
    </div>
  </footer>