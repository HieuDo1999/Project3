<!-- footer -->
<hr/>
<footer class="py-5 bg-dark" style=" position:absolute;width:100%;"
   ">
        <div class="container">
            <p class="m-0 text-center text-white">Food for everyone &copy; <a href="https://nentang.vn">HealthyFood.vn</a>
                &copy; 2020</p>
        </div>
    </footer>